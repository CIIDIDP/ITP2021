package teilchen.util;

import processing.core.PVector;

public class Linef {

    public PVector p1;

    public PVector p2;

    public Linef() {
        p1 = new PVector();
        p2 = new PVector();
    }
}
